const express = require("express");
const bodyParser = require("body-parser");
const http = require("http");
const { Server } = require("socket.io");
const webrtc = require("wrtc");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

let broadcasters = {}; // Map of broadcasterId to broadcaster info.

app.use(express.static("public"));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Broadcast endpoint
app.post("/broadcast", async ({ body }, res) => {
  const { sdp } = body;
  const broadcasterId = Math.floor(10000 + Math.random() * 90000); // Generate unique broadcaster ID.
  const peer = new webrtc.RTCPeerConnection({
    iceServers: [{ urls: "stun:stunprotocol.org" }],
  });

  peer.ontrack = (e) => {
    broadcasters[broadcasterId] = { peer, stream: e.streams[0] };
  };

  const desc = new webrtc.RTCSessionDescription(sdp);
  await peer.setRemoteDescription(desc);
  const answer = await peer.createAnswer();
  await peer.setLocalDescription(answer);

  res.json({ sdp: peer.localDescription, broadcasterId });
});

// Consumer endpoint
app.post("/consumer", async ({ body }, res) => {
  const { sdp, broadcasterId } = body;
  const broadcaster = broadcasters[broadcasterId];
  if (!broadcaster) {
    return res.status(404).json({ error: "Broadcaster not found" });
  }

  const peer = new webrtc.RTCPeerConnection({
    iceServers: [{ urls: "stun:stunprotocol.org" }],
  });

  const desc = new webrtc.RTCSessionDescription(sdp);
  await peer.setRemoteDescription(desc);

  broadcaster.stream
    .getTracks()
    .forEach((track) => peer.addTrack(track, broadcaster.stream));

  const answer = await peer.createAnswer();
  await peer.setLocalDescription(answer);

  res.json({ sdp: peer.localDescription });
});

// WebSocket Chat Functionality
io.on("connection", (socket) => {
  console.log("A user connected.");

  // Join a specific broadcaster's chat room
  socket.on("join-room", (broadcasterId) => {
    socket.join(broadcasterId); // Join the broadcaster's room
    console.log(`User joined broadcaster room: ${broadcasterId}`);
  });

  // Broadcast chat messages
  socket.on("send-message", ({ broadcasterId, username, message }) => {
    const chatMessage = `${username}: ${message}`;
    console.log(`Message to room ${broadcasterId}: ${chatMessage}`);

    // Emit to the broadcaster's room (both broadcaster and viewers)
    io.to(broadcasterId).emit("receive-message", chatMessage);
  });

  socket.on("disconnect", () => {
    console.log("A user disconnected.");
  });
});

server.listen(5000, () => console.log("Server started on port 5000"));
