window.onload = () => {
  document.getElementById("my-button").onclick = () => {
    init();
  };

  document.getElementById("send-chat").onclick = () => {
    const message = document.getElementById("chat-input").value;
    socket.emit("send-message", {
      broadcasterId,
      username: "Viewer",
      message,
    });
    addMessageToChat(`You: ${message}`);
  };
};

let broadcasterId;
let socket;

async function init() {
  broadcasterId = prompt("Enter the broadcaster ID to join:");
  const peer = createPeer(broadcasterId);
  peer.addTransceiver("video", { direction: "recvonly" });

  socket = io();
  socket.emit("join-room", broadcasterId); // Viewer joins the same room as the broadcaster

  socket.on("receive-message", (message) => {
    addMessageToChat(message);
  });

  socket.on("system-message", (message) => {
    addMessageToChat(`[System]: ${message}`);
  });
}

function createPeer(broadcasterId) {
  const peer = new RTCPeerConnection({
    iceServers: [{ urls: "stun:stunprotocol.org" }],
  });
  peer.ontrack = handleTrackEvent;
  peer.onnegotiationneeded = () =>
    handleNegotiationNeededEvent(peer, broadcasterId);

  return peer;
}

async function handleNegotiationNeededEvent(peer, broadcasterId) {
  const offer = await peer.createOffer();
  await peer.setLocalDescription(offer);
  const payload = { sdp: peer.localDescription, broadcasterId };

  const { data } = await axios.post("/consumer", payload);
  const desc = new RTCSessionDescription(data.sdp);
  peer.setRemoteDescription(desc).catch((e) => console.error(e));
}

function handleTrackEvent(e) {
  document.getElementById("video").srcObject = e.streams[0];
}

function addMessageToChat(message) {
  const chatBox = document.getElementById("chat-box");
  const messageElement = document.createElement("p");
  messageElement.textContent = message;
  chatBox.appendChild(messageElement);
}
