window.onload = () => {
  // Initialize the stream when the broadcaster clicks the "Start Stream" button
  document.getElementById("my-button").onclick = () => {
    init();
  };

  // Send message when the broadcaster clicks the "Send" button
  document.getElementById("send-chat").onclick = () => {
    const message = document.getElementById("chat-input").value;
    // Emit the chat message to the server
    socket.emit("send-message", {
      broadcasterId,
      username: "Broadcaster",
      message,
    });
    addMessageToChat(`You: ${message}`); // Display the message in the chat box
    document.getElementById("chat-input").value = ""; // Clear input field
  };
};

let broadcasterId;
let socket;

async function init() {
  // Get user media for video stream
  const stream = await navigator.mediaDevices.getUserMedia({ video: true });
  document.getElementById("video").srcObject = stream;

  // Create a peer connection and add the video stream
  const peer = createPeer();
  stream.getTracks().forEach((track) => peer.addTrack(track, stream));

  // Connect to the server with socket.io
  socket = io();
  socket.emit("join-room", broadcasterId); // Broadcaster joins the room

  // Listen for chat messages from other users (viewers)
  socket.on("receive-message", (message) => {
    addMessageToChat(message);
  });

  // Listen for system messages
  socket.on("system-message", (message) => {
    addMessageToChat(`[System]: ${message}`);
  });
}

function createPeer() {
  // Create and return a new RTCPeerConnection
  const peer = new RTCPeerConnection({
    iceServers: [{ urls: "stun:stunprotocol.org" }],
  });
  peer.onnegotiationneeded = () => handleNegotiationNeededEvent(peer);

  return peer;
}

async function handleNegotiationNeededEvent(peer) {
  // Handle WebRTC peer connection negotiation
  const offer = await peer.createOffer();
  await peer.setLocalDescription(offer);
  const payload = { sdp: peer.localDescription };

  // Send the offer to the server
  const { data } = await axios.post("/broadcast", payload);
  const desc = new RTCSessionDescription(data.sdp);
  peer.setRemoteDescription(desc).catch((e) => console.error(e));

  // Set the broadcaster ID after the offer
  broadcasterId = data.broadcasterId;
  alert(`Your Broadcaster ID: ${broadcasterId}`);
}

function addMessageToChat(message) {
  // Add a message to the chat box
  const chatBox = document.getElementById("chat-box");
  const messageElement = document.createElement("p");
  messageElement.textContent = message;
  chatBox.appendChild(messageElement);
}
